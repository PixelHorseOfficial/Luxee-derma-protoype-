// `initials` is what shows inside the gold avatar circle.
export const DOCTORS = [
  {
    name: "Dr. Deepthi",
    initials: "D",
    role: "Lead Dermatologist",
    quote: "Very knowledgeable, kind and incredibly helpful — explains every step.",
  },
  {
    name: "Dr. Aaron",
    initials: "A",
    role: "Aesthetic Physician",
    quote: "Attentive, calm and precise. Made me comfortable from first consultation.",
  },
  {
    name: "Dr. Arun",
    initials: "A",
    role: "Hair Restoration Specialist",
    quote: "4 sessions PRP — good results. Honest advice, no over-treatment.",
  },
];
