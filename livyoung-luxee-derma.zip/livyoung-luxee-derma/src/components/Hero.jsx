import { HERO_STATS } from "../data/hero";
import { SITE } from "../data/site";
import heroImage from "../assets/hero.webp";

export default function Hero({ onNavigate }) {
  return (
    <section
      id="hero"
      className="max-w-[1280px] mx-auto px-6 lg:px-8 pt-10 lg:pt-16 pb-12 lg:pb-20"
    >
      <div className="grid lg:grid-cols-[1.05fr_0.95fr] gap-12 lg:gap-12 items-center">
        {/* ---------- Left column: copy ---------- */}
        <div>
          <div className="inline-flex items-center gap-2 px-4 h-8 rounded-full bg-white border border-black/5 shadow-[0_2px_12px_rgba(0,0,0,0.04)] text-[11px] tracking-[0.12em] uppercase">
            <span className="w-5 h-5 rounded-full bg-[#F1E9DF] flex items-center justify-center text-[10px]">
              ★
            </span>
            Hyderabad's Most Rated Skin Clinic — {SITE.rating.score}/5
          </div>

          <h1 className="serif mt-6 text-[42px] lg:text-[68px] leading-[0.95] tracking-[-0.02em] font-[500]">
            Where Clinical
            <br />
            <span className="serif font-[400] italic text-[#C8A97A]">Excellence</span>{" "}
            Meets
            <br />
            Luxury Care.
          </h1>

          <p className="mt-6 text-[15px] lg:text-[17px] leading-[1.7] text-black/60 max-w-[520px] font-light">
            Advanced dermatology for pigmentation, acne, hair restoration and
            rejuvenation — delivered with gentle care, USFDA approved technology
            and top-notch sterilized protocols.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate("contact")}
              className="h-[50px] px-7 rounded-full bg-[#0B0B0B] text-white text-[13px] tracking-[0.12em] uppercase flex items-center gap-3"
            >
              Book Appointment{" "}
              <span className="w-6 h-6 rounded-full bg-white/15 flex items-center justify-center">
                →
              </span>
            </button>
            <button
              onClick={() => onNavigate("services")}
              className="h-[50px] px-7 rounded-full bg-white border border-black/10 text-[13px] tracking-[0.12em] uppercase hover:bg-[#F1E9DF]/60 transition"
            >
              View Treatments
            </button>
          </div>

          {/* Stats row */}
          <div className="mt-10 grid grid-cols-3 max-w-[520px] border-t border-black/10 pt-6">
            {HERO_STATS.map((stat, i) => (
              <div
                key={stat.label}
                className={i > 0 ? "border-l border-black/10 pl-6" : undefined}
              >
                <div className="serif text-[28px] leading-none">{stat.value}</div>
                <div className="text-[11px] tracking-[0.14em] uppercase opacity-60 mt-2">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 flex items-center gap-6 opacity-40 text-[11px] tracking-[0.18em] uppercase">
            <span>Featured in</span>
            <div className="flex gap-6 serif normal-case tracking-[0.04em] text-[13px]">
              Justdial • Practo • Google • ClinicSpots
            </div>
          </div>
        </div>

        {/* ---------- Right column: photo + floating cards ---------- */}
        <div className="relative">
          <div className="rounded-[2.2rem] overflow-hidden bg-[#F1E9DF] aspect-[4/5] lg:aspect-[4/4.7] shadow-[0_30px_80px_rgba(0,0,0,0.12)]">
            <img
              src={heroImage}
              alt="Livyoung Luxee Derma clinic interior"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none rounded-[2.2rem]" />
          </div>

          {/* Doctor card (bottom-left) */}
          <div className="absolute -left-4 lg:-left-10 bottom-[18%] bg-white rounded-[1.4rem] p-4 shadow-[0_20px_60px_rgba(0,0,0,0.12)] w-[260px] border border-black/5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#F1E9DF] flex items-center justify-center serif font-medium">
                DD
              </div>
              <div>
                <div className="text-[13px] font-medium">Dr. Deepthi</div>
                <div className="text-[11px] text-black/50 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                  Available Today • Lead Dermatologist
                </div>
              </div>
            </div>
            <div className="mt-3 text-[12px] leading-[1.5] text-black/60 bg-[#FAF7F5] rounded-xl p-3">
              “Very knowledgeable, kind and incredibly helpful — detailed
              consultation.”
            </div>
          </div>

          {/* Rating pill (top-right) */}
          <div className="absolute -right-3 lg:-right-6 top-[10%] bg-[#0B0B0B] text-white rounded-full px-4 h-9 flex items-center gap-2 shadow-[0_12px_30px_rgba(0,0,0,0.2)] text-[11px] tracking-[0.12em] uppercase">
            <span className="w-5 h-5 rounded-full bg-[#C8A97A] text-black flex items-center justify-center text-[10px]">
              ★
            </span>
            {SITE.rating.score} ({SITE.rating.count}) • Gentle Care
          </div>
        </div>
      </div>
    </section>
  );
}
