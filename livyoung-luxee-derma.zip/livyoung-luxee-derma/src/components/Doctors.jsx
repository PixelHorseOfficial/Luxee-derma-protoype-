import { DOCTORS } from "../data/doctors";

// Dark section. Reviews.jsx continues the same black background right below it.
export default function Doctors() {
  return (
    <section
      id="doctors"
      className="bg-[#0B0B0B] text-[#F1E9DF] rounded-t-[2.2rem] lg:rounded-t-[2.8rem]"
    >
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-16 lg:py-24">
        <div className="flex flex-wrap justify-between items-end gap-6">
          <h2 className="serif text-[36px] lg:text-[52px] leading-[0.95]">
            Meet The Experts
          </h2>
          <div className="text-[12px] tracking-[0.14em] uppercase opacity-50">
            Gentle Care • Detailed Consultations • Effective Treatments
          </div>
        </div>

        <div className="mt-10 grid md:grid-cols-3 gap-5">
          {DOCTORS.map(({ name, initials, role, quote }) => (
            <div
              key={name}
              className="rounded-[1.8rem] bg-white/[0.06] border border-white/10 p-8 backdrop-blur"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-[#C8A97A] text-[#0B0B0B] flex items-center justify-center serif text-[18px] font-medium">
                  {initials}
                </div>
                <div>
                  <div className="serif text-[18px]">{name}</div>
                  <div className="text-[11px] tracking-[0.14em] uppercase opacity-60">
                    {role}
                  </div>
                </div>
              </div>
              <div className="mt-6 text-[14px] leading-[1.6] opacity-80">
                “{quote}”
              </div>
              <div className="mt-6 flex gap-1 text-[#C8A97A] text-[12px]">★★★★★</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
