import { SITE } from "../data/site";

// Thin black strip above the header.
export default function AnnouncementBar() {
  return (
    <div className="w-full bg-[#0B0B0B] text-[#F1E9DF] text-[11px] tracking-[0.18em] uppercase py-[9px] px-4 flex justify-center items-center gap-6">
      <span className="hidden sm:inline-flex items-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-[#C8A97A] animate-pulse" />
        Available Now
      </span>

      <span className="flex items-center gap-1.5">
        {SITE.rating.score}★ ({SITE.rating.count} Reviews){" "}
        <span className="opacity-40 hidden md:inline">•</span>{" "}
        <span className="hidden md:inline">Claimed Business</span>
      </span>

      <span className="hidden lg:inline opacity-60">{SITE.address.topBar}</span>
    </div>
  );
}
