import { FOOTER_LINKS } from "../data/nav";
import { SITE } from "../data/site";

const SOCIAL = ["IG", "G", "JD"];

export default function Footer() {
  return (
    <footer className="bg-[#0B0B0B] text-[#F1E9DF]">
      {/* Gold hairline */}
      <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-[#C8A97A]/60 to-transparent" />

      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-12 lg:py-16 grid md:grid-cols-[1.2fr_0.8fr_0.8fr] gap-10">
        {/* Brand */}
        <div>
          <div className="leading-[0.9]">
            <div className="serif text-[20px] tracking-[0.14em]">{SITE.logo.line1}</div>
            <div className="serif text-[20px] tracking-[0.28em] font-light -mt-1">
              {SITE.logo.line2}
            </div>
          </div>
          <div className="mt-4 text-[13px] opacity-70 max-w-[320px] leading-[1.6]">
            {SITE.tagline}. Advanced dermatology rooted in safety, hygiene and
            honest consultations.
          </div>
          <div className="mt-6 flex gap-3">
            {SOCIAL.map((label) => (
              <span
                key={label}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-[12px]"
              >
                {label}
              </span>
            ))}
          </div>
        </div>

        {/* Explore */}
        <div className="text-[12px] tracking-[0.12em] uppercase space-y-3 opacity-80">
          <div className="opacity-40">Explore</div>
          {FOOTER_LINKS.map((label) => (
            <div key={label}>{label}</div>
          ))}
        </div>

        {/* Contact */}
        <div className="text-[12px] tracking-[0.04em] space-y-3 opacity-70">
          <div className="uppercase tracking-[0.12em] opacity-40">Contact</div>
          <div>{SITE.address.full}</div>
          <div>{SITE.address.landmark}</div>
          <div className="pt-2 opacity-50 text-[11px]">
            © {new Date().getFullYear()} {SITE.name}. All rights reserved. Clinical
            excellence meets luxury care.
          </div>
        </div>
      </div>
    </footer>
  );
}
