import { REVIEWS, REVIEW_AVATARS } from "../data/reviews";
import { SITE } from "../data/site";

export default function Reviews() {
  return (
    <section id="reviews" className="bg-[#0B0B0B] text-[#F1E9DF] pb-16 lg:pb-24">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
        <div className="rounded-[2rem] bg-[#FAF7F5] text-[#0B0B0B] p-6 lg:p-10 grid lg:grid-cols-[0.9fr_1.1fr] gap-8 items-center border border-white/10">
          {/* ---------- Summary ---------- */}
          <div>
            <div className="inline-flex items-center gap-2 text-[11px] tracking-[0.14em] uppercase">
              <span className="px-3 py-1 rounded-full bg-[#0B0B0B] text-white">
                {SITE.rating.score}★ • {SITE.rating.count} Reviews
              </span>
              <span className="opacity-50">Justdial • Google</span>
            </div>
            <h3 className="serif mt-4 text-[32px] leading-[0.95]">
              Real Stories. Real Skin.
            </h3>
            <p className="mt-3 text-[13px] text-black/60 leading-[1.6]">
              Verified reviews from Justdial. No filters, no incentives — only
              gentle care and visible change.
            </p>

            <div className="mt-6 flex items-center gap-3">
              <div className="flex -space-x-2">
                {REVIEW_AVATARS.map((initial) => (
                  <div
                    key={initial}
                    className="w-8 h-8 rounded-full bg-[#F1E9DF] border-2 border-white flex items-center justify-center text-[11px] font-medium"
                  >
                    {initial}
                  </div>
                ))}
              </div>
              <div className="text-[12px]">
                <span className="font-medium">Trusted by 5,000+</span>
                <br />
                <span className="opacity-60">Manikonda, Hyderabad</span>
              </div>
            </div>
          </div>

          {/* ---------- Review cards ---------- */}
          <div className="grid md:grid-cols-3 gap-4">
            {REVIEWS.map(({ name, tag, text }) => (
              <div
                key={name}
                className="rounded-[1.4rem] bg-white border border-black/5 p-5"
              >
                <div className="flex justify-between items-center">
                  <div className="text-[13px] font-medium">{name}</div>
                  <div className="text-[10px] tracking-[0.12em] uppercase px-2 py-1 rounded-full bg-[#F1E9DF]">
                    {tag}
                  </div>
                </div>
                <div className="mt-2 text-[#C8A97A] text-[11px]">★★★★★</div>
                <div className="mt-3 text-[12.5px] leading-[1.6] text-black/70">
                  “{text}”
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
