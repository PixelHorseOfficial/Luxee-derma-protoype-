import { TECH_FEATURES, TECH_PROCEDURES } from "../data/technology";
import technologyImage from "../assets/technology.webp";

export default function Technology() {
  return (
    <section
      id="technology"
      className="max-w-[1280px] mx-auto px-6 lg:px-8 py-16 lg:py-24"
    >
      <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
        {/* ---------- Photo with caption ---------- */}
        <div className="rounded-[2rem] overflow-hidden bg-[#F1E9DF] aspect-[4/3] lg:aspect-[4/3.2] relative">
          <img
            src={technologyImage}
            alt="Advanced dermatology treatment"
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-4 left-4 right-4 bg-white/85 glass rounded-[1.2rem] p-4 border border-white/50 flex items-center justify-between">
            <div className="text-[12px]">
              <span className="serif text-[16px]">Sterilized, Top-Notch</span>
              <br />
              <span className="opacity-60 tracking-[0.12em] uppercase text-[10px]">
                Infrastructure • USFDA Protocols
              </span>
            </div>
            <div className="w-9 h-9 rounded-full bg-[#0B0B0B] text-white flex items-center justify-center">
              ✓
            </div>
          </div>
        </div>

        {/* ---------- Copy + checklist ---------- */}
        <div>
          <div className="text-[11px] tracking-[0.2em] uppercase opacity-50">
            Why Luxee
          </div>
          <h2 className="serif mt-3 text-[36px] lg:text-[48px] leading-[0.95]">
            Technology That
            <br />
            Delivers Results
          </h2>
          <p className="mt-5 text-[14px] leading-[1.7] text-black/60 max-w-[480px]">
            We invest in devices that respect melanin-rich skin and deliver
            predictable outcomes — not trends.
          </p>

          <div className="mt-8 space-y-4">
            {TECH_FEATURES.map(({ title, desc }) => (
              <div
                key={title}
                className="flex gap-4 p-4 rounded-2xl bg-white border border-black/5"
              >
                <div className="w-8 h-8 rounded-full bg-[#F1E9DF] border border-[#C8A97A]/30 flex items-center justify-center text-[#C8A97A] text-[12px]">
                  ✓
                </div>
                <div>
                  <div className="text-[14px] font-medium">{title}</div>
                  <div className="text-[13px] text-black/55 mt-1 leading-[1.5]">
                    {desc}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 h-[1px] bg-black/10" />
          <div className="mt-6 flex gap-8 text-[11px] tracking-[0.12em] uppercase opacity-60">
            {TECH_PROCEDURES.map((name) => (
              <span key={name}>• {name}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
