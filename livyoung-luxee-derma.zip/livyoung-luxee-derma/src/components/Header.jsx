import { useState } from "react";
import useScrolled from "../hooks/useScrolled";
import { NAV_ITEMS } from "../data/nav";
import { SITE } from "../data/site";

// Sticky header: logo, desktop nav, "Book Consultation" button and mobile menu.
export default function Header({ activeSection, onNavigate, onLogoClick }) {
  const scrolled = useScrolled();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNav = (id) => {
    setMenuOpen(false);
    onNavigate(id);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all ${
        scrolled
          ? "bg-[#FAF7F5]/85 glass shadow-[0_8px_30px_rgba(0,0,0,0.04)] border-b border-[#0B0B0B]/[0.06]"
          : "bg-[#FAF7F5]/70 glass border-b border-transparent"
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 h-[72px] flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={onLogoClick}
          className="text-left leading-[0.9] cursor-pointer"
        >
          <div className="serif text-[18px] font-[600] tracking-[0.14em]">
            {SITE.logo.line1}
          </div>
          <div className="serif text-[18px] font-[400] tracking-[0.28em] -mt-1">
            {SITE.logo.line2}
          </div>
        </button>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-8 text-[13px] tracking-[0.08em] uppercase">
          {NAV_ITEMS.map(({ label, id }) => (
            <button
              key={id}
              onClick={() => handleNav(id)}
              className={`transition-all ${
                activeSection === id
                  ? "opacity-100 font-medium underline decoration-[#C8A97A] underline-offset-8 decoration-2"
                  : "opacity-70 hover:opacity-100"
              }`}
            >
              {label}
            </button>
          ))}
        </nav>

        {/* CTA + hamburger */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleNav("contact")}
            className="hidden md:inline-flex h-[40px] px-6 rounded-full bg-[#0B0B0B] text-white text-[12px] tracking-[0.12em] uppercase font-medium hover:bg-black transition"
          >
            Book Consultation
          </button>

          <button
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            className="lg:hidden w-10 h-10 rounded-full bg-white border border-black/10 flex items-center justify-center"
          >
            <div className="space-y-1.5">
              <div
                className={`w-4 h-[1.5px] bg-black transition ${
                  menuOpen ? "rotate-45 translate-y-[3px]" : ""
                }`}
              />
              <div
                className={`w-4 h-[1.5px] bg-black transition ${
                  menuOpen ? "opacity-0" : ""
                }`}
              />
              <div
                className={`w-4 h-[1.5px] bg-black transition ${
                  menuOpen ? "-rotate-45 -translate-y-[3px]" : ""
                }`}
              />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="lg:hidden border-t border-black/5 bg-[#FAF7F5] px-6 py-6 flex flex-col gap-5 text-[13px] tracking-[0.12em] uppercase">
          {NAV_ITEMS.map(({ label, id }) => (
            <button
              key={id}
              onClick={() => handleNav(id)}
              className="text-left py-1"
            >
              {label}
            </button>
          ))}
          <button
            onClick={() => handleNav("contact")}
            className="mt-2 h-[48px] rounded-full bg-[#0B0B0B] text-white"
          >
            Book Consultation
          </button>
        </div>
      )}
    </header>
  );
}
