import { RESULT_STATS } from "../data/results";

export default function Results() {
  return (
    <section
      id="results"
      className="max-w-[1280px] mx-auto px-6 lg:px-8 py-14 lg:py-20"
    >
      <div className="rounded-[2rem] bg-white border border-black/5 p-8 lg:p-10 flex flex-wrap justify-between gap-8 items-center">
        <div className="serif text-[28px] lg:text-[36px] leading-[0.95]">
          Results that look like
          <br />
          you, only clearer.
        </div>

        <div className="flex flex-wrap gap-10">
          {RESULT_STATS.map(({ value, label }) => (
            <div key={value} className="min-w-[160px]">
              <div className="serif text-[30px]">{value}</div>
              <div className="text-[11px] tracking-[0.1em] uppercase opacity-60 mt-1 max-w-[160px] leading-[1.4]">
                {label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
