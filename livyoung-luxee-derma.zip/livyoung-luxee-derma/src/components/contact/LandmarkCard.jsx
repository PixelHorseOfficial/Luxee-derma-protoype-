import { SITE } from "../../data/site";

export default function LandmarkCard() {
  return (
    <div className="rounded-[1.6rem] bg-[#0B0B0B] text-[#F1E9DF] p-6 flex items-center justify-between">
      <div>
        <div className="text-[13px] tracking-[0.14em] uppercase opacity-60">
          Landmark
        </div>
        <div className="serif text-[18px] mt-1">{SITE.address.landmark}</div>
      </div>
      <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
        ↗
      </div>
    </div>
  );
}
