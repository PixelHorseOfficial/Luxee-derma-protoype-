import { useState } from "react";
import { CONCERN_OPTIONS } from "../../data/booking";

const EMPTY_FORM = { name: "", phone: "", concern: "", date: "", message: "" };

// Shared look for the pill-shaped fields. Tweak once, applies to all inputs.
const FIELD_BASE =
  "w-full h-12 rounded-full bg-[#FAF7F5] border px-5 text-[14px] outline-none";
const LABEL_TEXT = "text-[11px] tracking-[0.12em] uppercase opacity-60";

export default function BookingForm({ onSuccess }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});

  const update = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Required";
    if (!form.phone.trim() || form.phone.length < 10)
      next.phone = "Valid phone required";
    if (!form.concern) next.concern = "Select concern";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    // TODO: send `form` to your backend / WhatsApp / CRM here.
    onSuccess?.(
      "Consultation requested — our care coordinator will call you within 30 minutes."
    );
    setForm(EMPTY_FORM);
  };

  return (
    <div className="bg-white rounded-[2rem] p-7 lg:p-10 border border-black/5 shadow-[0_20px_60px_rgba(0,0,0,0.06)]">
      <div className="text-[11px] tracking-[0.2em] uppercase opacity-50">
        Private Consultation
      </div>
      <h2 className="serif mt-3 text-[32px] lg:text-[40px] leading-[0.95]">
        Book Your
        <br />
        Skin Assessment
      </h2>
      <p className="mt-3 text-[13px] text-black/60">
        Response within 30 minutes • 10:00 AM - 8:30 PM • All days
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="space-y-2">
            <span className={LABEL_TEXT}>Full Name</span>
            <input
              value={form.name}
              onChange={update("name")}
              placeholder="Your name"
              className={`${FIELD_BASE} ${
                errors.name ? "border-red-400" : "border-black/10 focus:border-black/20"
              }`}
            />
          </label>

          <label className="space-y-2">
            <span className={LABEL_TEXT}>Phone</span>
            <input
              value={form.phone}
              onChange={update("phone")}
              placeholder="+91 • • • • •"
              className={`${FIELD_BASE} ${
                errors.phone ? "border-red-400" : "border-black/10 focus:border-black/20"
              }`}
            />
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="space-y-2">
            <span className={LABEL_TEXT}>Concern</span>
            <select
              value={form.concern}
              onChange={update("concern")}
              className={`${FIELD_BASE} ${
                errors.concern ? "border-red-400" : "border-black/10"
              }`}
            >
              <option value="">Select concern</option>
              {CONCERN_OPTIONS.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>

          <label className="space-y-2">
            <span className={LABEL_TEXT}>Preferred Date</span>
            <input
              type="date"
              value={form.date}
              onChange={update("date")}
              className={`${FIELD_BASE} border-black/10`}
            />
          </label>
        </div>

        <label className="space-y-2 block">
          <span className={LABEL_TEXT}>Message (optional)</span>
          <textarea
            value={form.message}
            onChange={update("message")}
            placeholder="Tell us about previous treatments, skin type, etc."
            rows={3}
            className="w-full rounded-[1.2rem] bg-[#FAF7F5] border border-black/10 p-5 text-[14px] outline-none focus:border-black/20 resize-none"
          />
        </label>

        <button
          type="submit"
          className="w-full h-[52px] rounded-full bg-[#0B0B0B] text-white text-[13px] tracking-[0.14em] uppercase font-medium hover:bg-black transition"
        >
          Request Callback • Free Assessment
        </button>

        <div className="text-[11px] text-black/50 text-center tracking-[0.02em]">
          By booking, you agree to gentle, honest care — no spam, no hard sell.
        </div>
      </form>
    </div>
  );
}
