import { SITE } from "../../data/site";

// White card with clinic name, address rows and Call / WhatsApp buttons.
export default function ClinicCard() {
  return (
    <div className="rounded-[2rem] bg-white border border-black/5 p-7 lg:p-8">
      <div className="flex justify-between items-start gap-4">
        <div>
          <div className="serif text-[22px]">{SITE.name}</div>
          <div className="text-[12px] opacity-60 mt-1 tracking-[0.04em]">
            {SITE.address.street}
          </div>
        </div>
        <div className="text-[11px] tracking-[0.12em] uppercase bg-[#0B0B0B] text-white px-3 py-1 rounded-full">
          Available Now
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-3 text-[13px]">
        <div className="flex gap-3">
          <span className="opacity-40">📍</span>
          <span>{SITE.address.near}</span>
        </div>
        <div className="flex gap-3">
          <span className="opacity-40">🕒</span>
          <span>{SITE.hours}</span>
        </div>
        <div className="flex gap-3">
          <span className="opacity-40">★</span>
          <span>
            {SITE.rating.score} • {SITE.rating.count} Ratings • Claimed Business •
            Gentle Care
          </span>
        </div>
      </div>

      <div className="mt-6 flex gap-3">
        <a
          href={SITE.phoneHref}
          className="flex-1 h-12 rounded-full bg-[#0B0B0B] text-white flex items-center justify-center gap-2 text-[12px] tracking-[0.12em] uppercase"
        >
          Call Clinic
        </a>
        <a
          href={SITE.whatsappHref}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 h-12 rounded-full bg-[#C8A97A] text-white flex items-center justify-center gap-2 text-[12px] tracking-[0.12em] uppercase"
        >
          WhatsApp
        </a>
      </div>
    </div>
  );
}
