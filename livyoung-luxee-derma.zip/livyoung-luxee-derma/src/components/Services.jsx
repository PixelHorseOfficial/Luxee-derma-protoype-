import { SERVICES } from "../data/services";

export default function Services() {
  return (
    <section id="services" className="bg-white border-y border-black/[0.06]">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-16 lg:py-24">
        {/* Heading row */}
        <div className="flex flex-wrap justify-between items-end gap-6">
          <div>
            <div className="text-[11px] tracking-[0.2em] uppercase opacity-50">
              Bespoke Solutions
            </div>
            <h2 className="serif mt-3 text-[36px] lg:text-[52px] leading-[0.95]">
              Bespoke Dermatology Solutions
            </h2>
          </div>
          <div className="text-[14px] text-black/50 max-w-[420px] leading-[1.6]">
            Clinical protocols curated for Indian skin tones — minimal downtime,
            maximal clarity, measured results.
          </div>
        </div>

        {/* Cards — edit the list in src/data/services.js */}
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceCard({ title, desc, icon, tag }) {
  return (
    <div className="group relative rounded-[1.8rem] bg-[#FAF7F5] border border-black/[0.06] p-7 lg:p-8 hover:bg-white hover:shadow-[0_20px_60px_rgba(0,0,0,0.06)] hover:-translate-y-1 transition-all duration-300">
      {tag && (
        <div className="absolute top-5 right-5 text-[10px] tracking-[0.14em] uppercase bg-[#0B0B0B] text-white px-3 py-1 rounded-full">
          {tag}
        </div>
      )}
      <div className="w-11 h-11 rounded-full bg-white border border-black/10 flex items-center justify-center text-[18px]">
        {icon}
      </div>
      <h3 className="serif mt-6 text-[20px] leading-[1.2]">{title}</h3>
      <p className="mt-3 text-[13.5px] leading-[1.6] text-black/60">{desc}</p>
      <div className="mt-6 flex items-center gap-2 text-[11px] tracking-[0.14em] uppercase opacity-60 group-hover:opacity-100 transition">
        <span>Explore Treatment</span> <span>→</span>
      </div>
    </div>
  );
}
