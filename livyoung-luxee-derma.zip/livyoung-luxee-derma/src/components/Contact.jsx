import BookingForm from "./contact/BookingForm";
import ClinicCard from "./contact/ClinicCard";
import ClinicMap from "./contact/ClinicMap";
import LandmarkCard from "./contact/LandmarkCard";

// "Contact" section = booking form (left) + clinic details, map and landmark (right).
// Each piece lives in its own file under ./contact/
export default function Contact({ onBooked }) {
  return (
    <section id="contact" className="bg-[#F1E9DF]/60 border-t border-black/5">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-16 lg:py-24 grid lg:grid-cols-2 gap-10 lg:gap-12">
        <BookingForm onSuccess={onBooked} />

        <div className="space-y-6">
          <ClinicCard />
          <ClinicMap />
          <LandmarkCard />
        </div>
      </div>
    </section>
  );
}
